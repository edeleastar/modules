package controllers;

import controllers.Response;
import org.eclipse.xtext.xbase.lib.Functions.Function0;

@SuppressWarnings("all")
public class Ok extends Response {
  public Ok(final String response) {
    super(new Function0<String>() {
      public String apply() {
        String _plus = ("ok\n" + response);
        return _plus;
      }
    }.apply());
  }
}
