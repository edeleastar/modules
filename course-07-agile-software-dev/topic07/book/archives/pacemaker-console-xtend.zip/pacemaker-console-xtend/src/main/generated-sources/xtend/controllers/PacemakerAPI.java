package controllers;

import com.google.common.base.Optional;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import models.Activity;
import models.Location;
import models.User;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import utils.DateTimeFormatters;
import utils.Serializer;

@SuppressWarnings("all")
public class PacemakerAPI {
  private static long userIndex = 0;
  
  private static long activityIndex = 0;
  
  private Map<Long,User> userMap = new Function0<Map<Long,User>>() {
    public Map<Long,User> apply() {
      HashMap<Long,User> _hashMap = new HashMap<Long,User>();
      return _hashMap;
    }
  }.apply();
  
  private Map<String,User> userEmailMap = new Function0<Map<String,User>>() {
    public Map<String,User> apply() {
      HashMap<String,User> _hashMap = new HashMap<String,User>();
      return _hashMap;
    }
  }.apply();
  
  private Map<Long,Activity> activityMap = new Function0<Map<Long,Activity>>() {
    public Map<Long,Activity> apply() {
      HashMap<Long,Activity> _hashMap = new HashMap<Long,Activity>();
      return _hashMap;
    }
  }.apply();
  
  private Collection<User> _users = new Function0<Collection<User>>() {
    public Collection<User> apply() {
      Collection<User> _values = PacemakerAPI.this.userMap.values();
      return _values;
    }
  }.apply();
  
  public Collection<User> getUsers() {
    return this._users;
  }
  
  public void setUsers(final Collection<User> users) {
    this._users = users;
  }
  
  private Serializer _serializer;
  
  public Serializer getSerializer() {
    return this._serializer;
  }
  
  public void setSerializer(final Serializer serializer) {
    this._serializer = serializer;
  }
  
  public PacemakerAPI() {
    PacemakerAPI.userIndex = 0;
    PacemakerAPI.activityIndex = 0;
  }
  
  public void load() throws Exception {
    Serializer _serializer = this.getSerializer();
    _serializer.read();
    Serializer _serializer_1 = this.getSerializer();
    Object _pop = _serializer_1.pop();
    PacemakerAPI.activityIndex = (((Long) _pop)).longValue();
    Serializer _serializer_2 = this.getSerializer();
    Object _pop_1 = _serializer_2.pop();
    PacemakerAPI.userIndex = (((Long) _pop_1)).longValue();
    Serializer _serializer_3 = this.getSerializer();
    Object _pop_2 = _serializer_3.pop();
    this.activityMap = ((Map<Long,Activity>) _pop_2);
    Serializer _serializer_4 = this.getSerializer();
    Object _pop_3 = _serializer_4.pop();
    this.userEmailMap = ((Map<String,User>) _pop_3);
    Serializer _serializer_5 = this.getSerializer();
    Object _pop_4 = _serializer_5.pop();
    this.userMap = ((Map<Long,User>) _pop_4);
    Collection<User> _values = this.userMap.values();
    this.setUsers(_values);
  }
  
  public void store() {
    Serializer _serializer = this.getSerializer();
    _serializer.push(this.userMap);
    Serializer _serializer_1 = this.getSerializer();
    _serializer_1.push(this.userEmailMap);
    Serializer _serializer_2 = this.getSerializer();
    _serializer_2.push(this.activityMap);
    Serializer _serializer_3 = this.getSerializer();
    _serializer_3.push(Long.valueOf(PacemakerAPI.userIndex));
    Serializer _serializer_4 = this.getSerializer();
    _serializer_4.push(Long.valueOf(PacemakerAPI.activityIndex));
    Serializer _serializer_5 = this.getSerializer();
    _serializer_5.write();
  }
  
  public Long createUser(final String firstName, final String lastName, final String email, final String password) {
    long _xblockexpression = (long) 0;
    {
      long _plus = (PacemakerAPI.userIndex + 1);
      PacemakerAPI.userIndex = _plus;
      User _user = new User(Long.valueOf(PacemakerAPI.userIndex), firstName, lastName, email, password);
      User user = _user;
      this.userMap.put(Long.valueOf(PacemakerAPI.userIndex), user);
      String _email = user.getEmail();
      this.userEmailMap.put(_email, user);
      _xblockexpression = (PacemakerAPI.userIndex);
    }
    return Long.valueOf(_xblockexpression);
  }
  
  public User getUser(final Long id) {
    User _get = this.userMap.get(id);
    return _get;
  }
  
  public User getUser(final String email) {
    User _get = this.userEmailMap.get(email);
    return _get;
  }
  
  public User deleteUser(final Long id) {
    User _xblockexpression = null;
    {
      User _get = this.userMap.get(id);
      this.userEmailMap.remove(_get);
      User _remove = this.userMap.remove(id);
      _xblockexpression = (_remove);
    }
    return _xblockexpression;
  }
  
  public User deleteUser(final String email) {
    User _xblockexpression = null;
    {
      User _user = this.getUser(email);
      final User user = this.userEmailMap.remove(_user);
      Long _id = user.getId();
      User _remove = this.userMap.remove(_id);
      _xblockexpression = (_remove);
    }
    return _xblockexpression;
  }
  
  public Activity createActivity(final Long id, final String type, final String location, final double distance, final String dateStr, final String durationStr) {
    Activity activity = null;
    User _get = this.userMap.get(id);
    Optional<User> user = Optional.<User>fromNullable(_get);
    boolean _isPresent = user.isPresent();
    if (_isPresent) {
      long _plus = (PacemakerAPI.activityIndex + 1);
      PacemakerAPI.activityIndex = _plus;
      DateTime _parseDateTime = DateTimeFormatters.parseDateTime(dateStr);
      Duration _parseDuration = DateTimeFormatters.parseDuration(durationStr);
      Activity _activity = new Activity(Long.valueOf(PacemakerAPI.activityIndex), type, location, distance, _parseDateTime, _parseDuration);
      activity = _activity;
      User _get_1 = user.get();
      Map<Long,Activity> _activities = _get_1.getActivities();
      Long _id = activity.getId();
      _activities.put(_id, activity);
      Long _id_1 = activity.getId();
      this.activityMap.put(_id_1, activity);
    }
    return activity;
  }
  
  public Activity getActivity(final Long id) {
    Activity _get = this.activityMap.get(id);
    return _get;
  }
  
  public void addLocation(final Long id, final float latitude, final float longitude) {
    Activity _get = this.activityMap.get(id);
    final Optional<Activity> activity = Optional.<Activity>fromNullable(_get);
    boolean _isPresent = activity.isPresent();
    if (_isPresent) {
      Activity _get_1 = activity.get();
      List<Location> _route = _get_1.getRoute();
      Location _location = new Location(latitude, longitude);
      _route.add(_location);
    }
  }
}
