package controllers;

import com.google.common.base.Objects;
import controllers.NotFound;
import controllers.Ok;
import controllers.PacemakerAPI;
import controllers.Response;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import models.Activity;
import models.User;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import parsers.Parser;

@SuppressWarnings("all")
public class PacemakerService {
  private PacemakerAPI pacemaker;
  
  private Parser parser;
  
  public PacemakerService(final PacemakerAPI pacemaker, final Parser parser) {
    this.pacemaker = pacemaker;
    this.parser = parser;
  }
  
  public Ok createUser(final String firstname, final String lastname, final String email, final String password) {
    Ok _xblockexpression = null;
    {
      final Long id = this.pacemaker.createUser(firstname, lastname, email, password);
      User _user = this.pacemaker.getUser(id);
      String _renderUser = this.parser.renderUser(_user);
      Ok _ok = new Ok(_renderUser);
      _xblockexpression = (_ok);
    }
    return _xblockexpression;
  }
  
  public Response getUser(final Long id) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        String _renderUser = this.parser.renderUser(user);
        Ok _ok = new Ok(_renderUser);
        _xifexpression = _ok;
      } else {
        NotFound _notFound = new NotFound("");
        _xifexpression = _notFound;
      }
      _xblockexpression = (_xifexpression);
    }
    return _xblockexpression;
  }
  
  public Response getUser(final String email) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(email);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        Long _id = user.getId();
        Response _user = this.getUser(_id);
        _xifexpression = _user;
      } else {
        NotFound _notFound = new NotFound("");
        _xifexpression = _notFound;
      }
      _xblockexpression = (_xifexpression);
    }
    return _xblockexpression;
  }
  
  public Ok getUsers() {
    Collection<User> _users = this.pacemaker.getUsers();
    String _renderUsers = this.parser.renderUsers(_users);
    Ok _ok = new Ok(_renderUsers);
    return _ok;
  }
  
  public Response deleteUser(final Long id) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(id);
      Long _id = null;
      if (user!=null) {
        _id=user.getId();
      }
      this.pacemaker.deleteUser(_id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        Ok _ok = new Ok("");
        _xifexpression = _ok;
      } else {
        NotFound _notFound = new NotFound("");
        _xifexpression = _notFound;
      }
      _xblockexpression = (_xifexpression);
    }
    return _xblockexpression;
  }
  
  public Response createActivity(final Long id, final String type, final String location, final double distance, final String dateStr, final String durationStr) {
    Response _xifexpression = null;
    User _user = this.pacemaker.getUser(id);
    boolean _notEquals = (!Objects.equal(null, _user));
    if (_notEquals) {
      Ok _xblockexpression = null;
      {
        this.pacemaker.createActivity(id, type, location, distance, dateStr, durationStr);
        Ok _ok = new Ok("");
        _xblockexpression = (_ok);
      }
      _xifexpression = _xblockexpression;
    } else {
      NotFound _notFound = new NotFound("");
      _xifexpression = _notFound;
    }
    return _xifexpression;
  }
  
  public Response getActivities(final Long id) {
    Response _xblockexpression = null;
    {
      final User user = this.pacemaker.getUser(id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, user));
      if (_notEquals) {
        Map<Long,Activity> _activities = user.getActivities();
        Collection<Activity> _values = _activities.values();
        String _renderActivities = this.parser.renderActivities(_values);
        Ok _ok = new Ok(_renderActivities);
        _xifexpression = _ok;
      } else {
        NotFound _notFound = new NotFound("");
        _xifexpression = _notFound;
      }
      _xblockexpression = (_xifexpression);
    }
    return _xblockexpression;
  }
  
  public Response addLocation(final Long id, final float latitude, final float longitude) {
    Response _xblockexpression = null;
    {
      final Activity activity = this.pacemaker.getActivity(id);
      Response _xifexpression = null;
      boolean _notEquals = (!Objects.equal(null, activity));
      if (_notEquals) {
        Ok _xblockexpression_1 = null;
        {
          this.pacemaker.addLocation(id, latitude, longitude);
          Ok _ok = new Ok("");
          _xblockexpression_1 = (_ok);
        }
        _xifexpression = _xblockexpression_1;
      } else {
        NotFound _notFound = new NotFound("");
        _xifexpression = _notFound;
      }
      _xblockexpression = (_xifexpression);
    }
    return _xblockexpression;
  }
  
  public Ok listActivities(final Long id, final String sortBy) {
    User _user = this.pacemaker.getUser(id);
    Map<Long,Activity> _activities = _user.getActivities();
    final Collection<Activity> activities = _activities.values();
    List<Activity> _switchResult = null;
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(sortBy,"type")) {
        _matched=true;
        final Function1<Activity,String> _function = new Function1<Activity,String>() {
            public String apply(final Activity it) {
              String _type = it.getType();
              return _type;
            }
          };
        List<Activity> _sortBy = IterableExtensions.<Activity, String>sortBy(activities, _function);
        _switchResult = _sortBy;
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy,"location")) {
        _matched=true;
        final Function1<Activity,String> _function_1 = new Function1<Activity,String>() {
            public String apply(final Activity it) {
              String _location = it.getLocation();
              return _location;
            }
          };
        List<Activity> _sortBy_1 = IterableExtensions.<Activity, String>sortBy(activities, _function_1);
        _switchResult = _sortBy_1;
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy,"distance")) {
        _matched=true;
        final Function1<Activity,Double> _function_2 = new Function1<Activity,Double>() {
            public Double apply(final Activity it) {
              double _distance = it.getDistance();
              return Double.valueOf(_distance);
            }
          };
        List<Activity> _sortBy_2 = IterableExtensions.<Activity, Double>sortBy(activities, _function_2);
        _switchResult = _sortBy_2;
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy,"date")) {
        _matched=true;
        final Function1<Activity,DateTime> _function_3 = new Function1<Activity,DateTime>() {
            public DateTime apply(final Activity it) {
              DateTime _starttime = it.getStarttime();
              return _starttime;
            }
          };
        List<Activity> _sortBy_3 = IterableExtensions.<Activity, DateTime>sortBy(activities, _function_3);
        _switchResult = _sortBy_3;
      }
    }
    if (!_matched) {
      if (Objects.equal(sortBy,"duration")) {
        _matched=true;
        final Function1<Activity,Duration> _function_4 = new Function1<Activity,Duration>() {
            public Duration apply(final Activity it) {
              Duration _duration = it.getDuration();
              return _duration;
            }
          };
        List<Activity> _sortBy_4 = IterableExtensions.<Activity, Duration>sortBy(activities, _function_4);
        _switchResult = _sortBy_4;
      }
    }
    final List<Activity> report = _switchResult;
    String _renderActivities = this.parser.renderActivities(report);
    Ok _ok = new Ok(_renderActivities);
    return _ok;
  }
}
