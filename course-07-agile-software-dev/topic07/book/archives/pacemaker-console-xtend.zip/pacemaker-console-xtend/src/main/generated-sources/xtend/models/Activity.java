package models;

import java.util.ArrayList;
import java.util.List;
import models.Location;
import org.eclipse.xtend.lib.Data;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.util.ToStringHelper;
import org.joda.time.DateTime;
import org.joda.time.Duration;

@Data
@SuppressWarnings("all")
public class Activity {
  private final Long _id;
  
  public Long getId() {
    return this._id;
  }
  
  private final String _type;
  
  public String getType() {
    return this._type;
  }
  
  private final String _location;
  
  public String getLocation() {
    return this._location;
  }
  
  private final double _distance;
  
  public double getDistance() {
    return this._distance;
  }
  
  private final DateTime _starttime;
  
  public DateTime getStarttime() {
    return this._starttime;
  }
  
  private final Duration _duration;
  
  public Duration getDuration() {
    return this._duration;
  }
  
  private final List<Location> _route = new Function0<List<Location>>() {
    public List<Location> apply() {
      ArrayList<Location> _arrayList = new ArrayList<Location>();
      return _arrayList;
    }
  }.apply();
  
  public List<Location> getRoute() {
    return this._route;
  }
  
  public Activity(final Long id, final String type, final String location, final double distance, final DateTime starttime, final Duration duration) {
    super();
    this._id = id;
    this._type = type;
    this._location = location;
    this._distance = distance;
    this._starttime = starttime;
    this._duration = duration;
  }
  
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((_id== null) ? 0 : _id.hashCode());
    result = prime * result + ((_type== null) ? 0 : _type.hashCode());
    result = prime * result + ((_location== null) ? 0 : _location.hashCode());
    result = prime * result + (int) (Double.doubleToLongBits(_distance) ^ (Double.doubleToLongBits(_distance) >>> 32));
    result = prime * result + ((_starttime== null) ? 0 : _starttime.hashCode());
    result = prime * result + ((_duration== null) ? 0 : _duration.hashCode());
    result = prime * result + ((_route== null) ? 0 : _route.hashCode());
    return result;
  }
  
  @Override
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Activity other = (Activity) obj;
    if (_id == null) {
      if (other._id != null)
        return false;
    } else if (!_id.equals(other._id))
      return false;
    if (_type == null) {
      if (other._type != null)
        return false;
    } else if (!_type.equals(other._type))
      return false;
    if (_location == null) {
      if (other._location != null)
        return false;
    } else if (!_location.equals(other._location))
      return false;
    if (Double.doubleToLongBits(other._distance) != Double.doubleToLongBits(_distance))
      return false;
    if (_starttime == null) {
      if (other._starttime != null)
        return false;
    } else if (!_starttime.equals(other._starttime))
      return false;
    if (_duration == null) {
      if (other._duration != null)
        return false;
    } else if (!_duration.equals(other._duration))
      return false;
    if (_route == null) {
      if (other._route != null)
        return false;
    } else if (!_route.equals(other._route))
      return false;
    return true;
  }
  
  @Override
  public String toString() {
    String result = new ToStringHelper().toString(this);
    return result;
  }
}
