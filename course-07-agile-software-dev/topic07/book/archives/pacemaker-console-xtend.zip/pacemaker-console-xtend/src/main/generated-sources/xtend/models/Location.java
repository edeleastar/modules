package models;

import org.eclipse.xtend.lib.Data;

@Data
@SuppressWarnings("all")
public class Location {
  private final float _latitude;
  
  public float getLatitude() {
    return this._latitude;
  }
  
  private final float _longitude;
  
  public float getLongitude() {
    return this._longitude;
  }
  
  public String toString() {
    float _latitude = this.getLatitude();
    String _plus = (Float.valueOf(_latitude) + ",");
    float _longitude = this.getLongitude();
    return (_plus + Float.valueOf(_longitude));
  }
  
  public Location(final float latitude, final float longitude) {
    super();
    this._latitude = latitude;
    this._longitude = longitude;
  }
  
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + Float.floatToIntBits(_latitude);
    result = prime * result + Float.floatToIntBits(_longitude);
    return result;
  }
  
  @Override
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Location other = (Location) obj;
    if (Float.floatToIntBits(other._latitude) != Float.floatToIntBits(_latitude))
      return false;
    if (Float.floatToIntBits(other._longitude) != Float.floatToIntBits(_longitude))
      return false;
    return true;
  }
}
