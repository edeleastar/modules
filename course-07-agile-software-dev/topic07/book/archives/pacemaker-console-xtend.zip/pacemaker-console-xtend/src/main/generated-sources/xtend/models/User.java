package models;

import java.util.HashMap;
import java.util.Map;
import models.Activity;
import org.eclipse.xtend.lib.Data;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.util.ToStringHelper;

@Data
@SuppressWarnings("all")
public class User {
  private final Long _id;
  
  public Long getId() {
    return this._id;
  }
  
  private final String _firstname;
  
  public String getFirstname() {
    return this._firstname;
  }
  
  private final String _lastname;
  
  public String getLastname() {
    return this._lastname;
  }
  
  private final String _email;
  
  public String getEmail() {
    return this._email;
  }
  
  private final String _password;
  
  public String getPassword() {
    return this._password;
  }
  
  private final Map<Long,Activity> _activities = new Function0<Map<Long,Activity>>() {
    public Map<Long,Activity> apply() {
      HashMap<Long,Activity> _hashMap = new HashMap<Long,Activity>();
      return _hashMap;
    }
  }.apply();
  
  public Map<Long,Activity> getActivities() {
    return this._activities;
  }
  
  public User(final Long id, final String firstname, final String lastname, final String email, final String password) {
    super();
    this._id = id;
    this._firstname = firstname;
    this._lastname = lastname;
    this._email = email;
    this._password = password;
  }
  
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((_id== null) ? 0 : _id.hashCode());
    result = prime * result + ((_firstname== null) ? 0 : _firstname.hashCode());
    result = prime * result + ((_lastname== null) ? 0 : _lastname.hashCode());
    result = prime * result + ((_email== null) ? 0 : _email.hashCode());
    result = prime * result + ((_password== null) ? 0 : _password.hashCode());
    result = prime * result + ((_activities== null) ? 0 : _activities.hashCode());
    return result;
  }
  
  @Override
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    User other = (User) obj;
    if (_id == null) {
      if (other._id != null)
        return false;
    } else if (!_id.equals(other._id))
      return false;
    if (_firstname == null) {
      if (other._firstname != null)
        return false;
    } else if (!_firstname.equals(other._firstname))
      return false;
    if (_lastname == null) {
      if (other._lastname != null)
        return false;
    } else if (!_lastname.equals(other._lastname))
      return false;
    if (_email == null) {
      if (other._email != null)
        return false;
    } else if (!_email.equals(other._email))
      return false;
    if (_password == null) {
      if (other._password != null)
        return false;
    } else if (!_password.equals(other._password))
      return false;
    if (_activities == null) {
      if (other._activities != null)
        return false;
    } else if (!_activities.equals(other._activities))
      return false;
    return true;
  }
  
  @Override
  public String toString() {
    String result = new ToStringHelper().toString(this);
    return result;
  }
}
