package parsers;

import com.fasterxml.jackson.annotation.JsonIgnore;

@SuppressWarnings("all")
public interface ActivityMixin {
  @JsonIgnore
  public abstract Long getId();
}
