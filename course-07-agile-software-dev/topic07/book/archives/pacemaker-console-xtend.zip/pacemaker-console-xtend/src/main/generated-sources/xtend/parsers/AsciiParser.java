package parsers;

import com.bethecoder.ascii_table.ASCIITable;
import com.bethecoder.ascii_table.impl.CollectionASCIITableAware;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import models.Activity;
import models.User;
import parsers.Parser;

@SuppressWarnings("all")
public class AsciiParser extends Parser {
  public String renderUser(final User user) {
    String _xblockexpression = null;
    {
      ArrayList<User> _arrayList = new ArrayList<User>();
      final List<User> userList = _arrayList;
      userList.add(user);
      String _renderUsers = this.renderUsers(userList);
      _xblockexpression = (_renderUsers);
    }
    return _xblockexpression;
  }
  
  public String renderActivities(final Collection<Activity> activities) {
    String _xifexpression = null;
    boolean _isEmpty = activities.isEmpty();
    boolean _not = (!_isEmpty);
    if (_not) {
      String _xblockexpression = null;
      {
        ArrayList<Activity> _arrayList = new ArrayList<Activity>(activities);
        final List<Activity> activityList = _arrayList;
        CollectionASCIITableAware<Activity> _collectionASCIITableAware = new CollectionASCIITableAware<Activity>(activityList, "id", "type", "location", "distance", "starttime", "duration", "route");
        CollectionASCIITableAware<Activity> activitiesTable = _collectionASCIITableAware;
        ASCIITable _instance = ASCIITable.getInstance();
        String _table = _instance.getTable(activitiesTable);
        _xblockexpression = (_table);
      }
      _xifexpression = _xblockexpression;
    }
    return _xifexpression;
  }
  
  public String renderUsers(final Collection<User> users) {
    String _xifexpression = null;
    boolean _isEmpty = users.isEmpty();
    boolean _not = (!_isEmpty);
    if (_not) {
      String _xblockexpression = null;
      {
        ArrayList<User> _arrayList = new ArrayList<User>(users);
        final List<User> userList = _arrayList;
        CollectionASCIITableAware<User> _collectionASCIITableAware = new CollectionASCIITableAware<User>(userList, "id", "firstname", "lastname", "email", "password");
        CollectionASCIITableAware<User> asciiTableAware = _collectionASCIITableAware;
        ASCIITable _instance = ASCIITable.getInstance();
        String _table = _instance.getTable(asciiTableAware);
        _xblockexpression = (_table);
      }
      _xifexpression = _xblockexpression;
    }
    return _xifexpression;
  }
}
