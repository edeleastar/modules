package parsers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import java.util.Collection;
import models.Activity;
import models.User;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import parsers.ActivityMixin;
import parsers.Parser;
import parsers.UserMixin;

@SuppressWarnings("all")
public class JsonParser extends Parser {
  private final ObjectMapper mapper = new Function0<ObjectMapper>() {
    public ObjectMapper apply() {
      ObjectMapper _objectMapper = new ObjectMapper();
      return _objectMapper;
    }
  }.apply();
  
  public JsonParser() {
    this.mapper.addMixInAnnotations(User.class, UserMixin.class);
    this.mapper.addMixInAnnotations(Activity.class, ActivityMixin.class);
  }
  
  public String renderUser(final User user) {
    try {
      ObjectWriter _writerWithDefaultPrettyPrinter = this.mapper.writerWithDefaultPrettyPrinter();
      String _writeValueAsString = _writerWithDefaultPrettyPrinter.writeValueAsString(user);
      return _writeValueAsString;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public String renderActivities(final Collection<Activity> activities) {
    try {
      String _xifexpression = null;
      int _size = activities.size();
      boolean _greaterThan = (_size > 0);
      if (_greaterThan) {
        ObjectWriter _writerWithDefaultPrettyPrinter = this.mapper.writerWithDefaultPrettyPrinter();
        String _writeValueAsString = _writerWithDefaultPrettyPrinter.writeValueAsString(activities);
        _xifexpression = _writeValueAsString;
      }
      return _xifexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public String renderUsers(final Collection<User> users) {
    try {
      ObjectWriter _writerWithDefaultPrettyPrinter = this.mapper.writerWithDefaultPrettyPrinter();
      String _writeValueAsString = _writerWithDefaultPrettyPrinter.writeValueAsString(users);
      return _writeValueAsString;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
