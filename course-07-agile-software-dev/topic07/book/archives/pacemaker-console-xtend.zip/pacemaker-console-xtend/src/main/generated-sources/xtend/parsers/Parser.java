package parsers;

import java.util.Collection;
import models.Activity;
import models.User;

@SuppressWarnings("all")
public class Parser {
  public String renderUser(final User user) {
    String _string = user.toString();
    return _string;
  }
  
  public String renderUsers(final Collection<User> users) {
    String _string = users.toString();
    return _string;
  }
  
  public String renderActivities(final Collection<Activity> activities) {
    String _string = activities.toString();
    return _string;
  }
}
