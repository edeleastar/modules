package parsers;

import com.fasterxml.jackson.annotation.JsonIgnore;

@SuppressWarnings("all")
public interface UserMixin {
  @JsonIgnore
  public abstract String getActivities();
  
  @JsonIgnore
  public abstract Long getId();
}
