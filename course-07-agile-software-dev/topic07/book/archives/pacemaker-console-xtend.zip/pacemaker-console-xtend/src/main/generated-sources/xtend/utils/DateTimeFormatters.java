package utils;

import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.PeriodFormatter;
import org.joda.time.format.PeriodFormatterBuilder;

@SuppressWarnings("all")
public class DateTimeFormatters {
  private final static PeriodFormatter periodFormatter = new Function0<PeriodFormatter>() {
    public PeriodFormatter apply() {
      PeriodFormatterBuilder _periodFormatterBuilder = new PeriodFormatterBuilder();
      PeriodFormatterBuilder _printZeroAlways = _periodFormatterBuilder.printZeroAlways();
      PeriodFormatterBuilder _appendHours = _printZeroAlways.appendHours();
      PeriodFormatterBuilder _appendSeparator = _appendHours.appendSeparator(":");
      PeriodFormatterBuilder _appendMinutes = _appendSeparator.appendMinutes();
      PeriodFormatterBuilder _appendSeparator_1 = _appendMinutes.appendSeparator(":");
      PeriodFormatterBuilder _appendSeconds = _appendSeparator_1.appendSeconds();
      PeriodFormatter _formatter = _appendSeconds.toFormatter();
      return _formatter;
    }
  }.apply();
  
  private final static DateTimeFormatter dateFormatter = new Function0<DateTimeFormatter>() {
    public DateTimeFormatter apply() {
      DateTimeFormatter _forPattern = DateTimeFormat.forPattern("dd:MM:yyyy HH:mm:ss");
      return _forPattern;
    }
  }.apply();
  
  public static DateTime parseDateTime(final String dateTime) {
    DateTime _parseDateTime = DateTimeFormatters.dateFormatter.parseDateTime(dateTime);
    DateTime _dateTime = new DateTime(_parseDateTime);
    return _dateTime;
  }
  
  public static String parseDateTime(final DateTime dateTime) {
    String _print = DateTimeFormatters.dateFormatter.print(dateTime);
    return _print;
  }
  
  public static Duration parseDuration(final String duration) {
    Period _parsePeriod = DateTimeFormatters.periodFormatter.parsePeriod(duration);
    Duration _standardDuration = _parsePeriod.toStandardDuration();
    return _standardDuration;
  }
  
  public static String parseDuration(final Duration duration) {
    Period _period = duration.toPeriod();
    String _print = DateTimeFormatters.periodFormatter.print(_period);
    return _print;
  }
}
