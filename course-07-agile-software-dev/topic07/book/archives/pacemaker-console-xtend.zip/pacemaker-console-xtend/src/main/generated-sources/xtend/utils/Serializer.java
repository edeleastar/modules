package utils;

@SuppressWarnings("all")
public interface Serializer {
  public abstract void push(final Object o);
  
  public abstract Object pop();
  
  public abstract void write();
  
  public abstract void read();
}
