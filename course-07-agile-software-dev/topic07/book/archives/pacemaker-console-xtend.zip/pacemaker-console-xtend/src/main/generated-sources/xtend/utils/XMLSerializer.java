package utils;

import com.google.common.base.Objects;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import utils.Serializer;

@SuppressWarnings("all")
public class XMLSerializer implements Serializer {
  private Deque<Object> stack = new Function0<Deque<Object>>() {
    public Deque<Object> apply() {
      ArrayDeque<Object> _arrayDeque = new ArrayDeque<Object>();
      return _arrayDeque;
    }
  }.apply();
  
  private final File file;
  
  public XMLSerializer(final String filename) {
    String _plus = (filename + ".xml");
    File _file = new File(_plus);
    this.file = _file;
  }
  
  public void push(final Object o) {
    this.stack.push(o);
  }
  
  public Object pop() {
    return this.stack.pop();
  }
  
  @SuppressWarnings("unchecked")
  public void read() {
    try {
      ObjectInputStream is = null;
      try {
        DomDriver _domDriver = new DomDriver();
        XStream _xStream = new XStream(_domDriver);
        final XStream xstream = _xStream;
        FileReader _fileReader = new FileReader(this.file);
        ObjectInputStream _createObjectInputStream = xstream.createObjectInputStream(_fileReader);
        is = _createObjectInputStream;
        Object _readObject = is.readObject();
        this.stack = ((Deque<Object>) _readObject);
      } finally {
        boolean _notEquals = (!Objects.equal(is, null));
        if (_notEquals) {
          is.close();
        }
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public void write() {
    try {
      ObjectOutputStream os = null;
      try {
        DomDriver _domDriver = new DomDriver();
        XStream _xStream = new XStream(_domDriver);
        final XStream xstream = _xStream;
        FileWriter _fileWriter = new FileWriter(this.file);
        ObjectOutputStream _createObjectOutputStream = xstream.createObjectOutputStream(_fileWriter);
        os = _createObjectOutputStream;
        os.writeObject(this.stack);
      } finally {
        boolean _notEquals = (!Objects.equal(os, null));
        if (_notEquals) {
          os.close();
        }
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
