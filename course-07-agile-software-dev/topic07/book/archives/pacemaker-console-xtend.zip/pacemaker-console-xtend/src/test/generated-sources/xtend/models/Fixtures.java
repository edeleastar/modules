package models;

import java.util.ArrayList;
import models.Activity;
import models.Location;
import models.User;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.joda.time.DateTime;
import org.joda.time.Duration;

@SuppressWarnings("all")
public class Fixtures {
  public final static ArrayList<User> users = new Function0<ArrayList<User>>() {
    public ArrayList<User> apply() {
      User _user = new User(Long.valueOf(1l), "marge", "simpson", "marge@simpson.com", "secret");
      User _user_1 = new User(Long.valueOf(2l), "lisa", "simpson", "lisa@simpson.com", "secret");
      User _user_2 = new User(Long.valueOf(3l), "bart", "simpson", "bart@simpson.com", "secret");
      User _user_3 = new User(Long.valueOf(4l), "maggie", "simpson", "maggie@simpson.com", "secret");
      ArrayList<User> _newArrayList = CollectionLiterals.<User>newArrayList(_user, _user_1, _user_2, _user_3);
      return _newArrayList;
    }
  }.apply();
  
  public final static ArrayList<Activity> activities = new Function0<ArrayList<Activity>>() {
    public ArrayList<Activity> apply() {
      DateTime _dateTime = new DateTime(2013, 5, 12, 9, 30);
      Duration _duration = new Duration(10000);
      Activity _activity = new Activity(Long.valueOf(1l), "walk", "fridge", 0.001, _dateTime, _duration);
      DateTime _dateTime_1 = new DateTime(2013, 5, 17, 10, 30);
      Duration _duration_1 = new Duration(30000);
      Activity _activity_1 = new Activity(Long.valueOf(2l), "walk", "bar", 1.0, _dateTime_1, _duration_1);
      DateTime _dateTime_2 = new DateTime(2013, 6, 10, 11, 00);
      Duration _duration_2 = new Duration(50000);
      Activity _activity_2 = new Activity(Long.valueOf(3l), "run", "work", 2.2, _dateTime_2, _duration_2);
      DateTime _dateTime_3 = new DateTime(2013, 7, 22, 9, 00);
      Duration _duration_3 = new Duration(60000);
      Activity _activity_3 = new Activity(Long.valueOf(4l), "walk", "shop", 2.5, _dateTime_3, _duration_3);
      DateTime _dateTime_4 = new DateTime(2013, 8, 30, 9, 30);
      Duration _duration_4 = new Duration(70000);
      Activity _activity_4 = new Activity(Long.valueOf(5l), "cycle", "school", 4.5, _dateTime_4, _duration_4);
      ArrayList<Activity> _newArrayList = CollectionLiterals.<Activity>newArrayList(_activity, _activity_1, _activity_2, _activity_3, _activity_4);
      return _newArrayList;
    }
  }.apply();
  
  public final static ArrayList<Location> locations = new Function0<ArrayList<Location>>() {
    public ArrayList<Location> apply() {
      Location _location = new Location(23.3f, 33.3f);
      Location _location_1 = new Location(34.4f, 45.2f);
      Location _location_2 = new Location(25.3f, 34.3f);
      Location _location_3 = new Location(44.4f, 23.3f);
      ArrayList<Location> _newArrayList = CollectionLiterals.<Location>newArrayList(_location, _location_1, _location_2, _location_3);
      return _newArrayList;
    }
  }.apply();
  
  public final static ArrayList<Activity> margesActivities = new Function0<ArrayList<Activity>>() {
    public ArrayList<Activity> apply() {
      Activity _get = Fixtures.activities.get(0);
      Activity _get_1 = Fixtures.activities.get(1);
      Activity _get_2 = Fixtures.activities.get(2);
      ArrayList<Activity> _newArrayList = CollectionLiterals.<Activity>newArrayList(_get, _get_1, _get_2);
      return _newArrayList;
    }
  }.apply();
  
  public final static ArrayList<Activity> lisasActivities = new Function0<ArrayList<Activity>>() {
    public ArrayList<Activity> apply() {
      Activity _get = Fixtures.activities.get(3);
      Activity _get_1 = Fixtures.activities.get(4);
      ArrayList<Activity> _newArrayList = CollectionLiterals.<Activity>newArrayList(_get, _get_1);
      return _newArrayList;
    }
  }.apply();
  
  public final static ArrayList<Location> route1 = new Function0<ArrayList<Location>>() {
    public ArrayList<Location> apply() {
      Location _get = Fixtures.locations.get(0);
      Location _get_1 = Fixtures.locations.get(1);
      ArrayList<Location> _newArrayList = CollectionLiterals.<Location>newArrayList(_get, _get_1);
      return _newArrayList;
    }
  }.apply();
  
  public final static ArrayList<Location> route2 = new Function0<ArrayList<Location>>() {
    public ArrayList<Location> apply() {
      Location _get = Fixtures.locations.get(2);
      Location _get_1 = Fixtures.locations.get(3);
      ArrayList<Location> _newArrayList = CollectionLiterals.<Location>newArrayList(_get, _get_1);
      return _newArrayList;
    }
  }.apply();
}
