package models;

import java.util.HashMap;
import models.User;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class FixturesComposite {
  public final static HashMap<Long,User> userMap = new Function0<HashMap<Long,User>>() {
    public HashMap<Long,User> apply() {
      User _user = new User(Long.valueOf(1l), "marge", "simpson", "marge@simpson.com", "secret");
      Pair<Long,User> _mappedTo = Pair.<Long, User>of(Long.valueOf(01l), _user);
      HashMap<Long,User> _newHashMap = CollectionLiterals.<Long, User>newHashMap(_mappedTo);
      return _newHashMap;
    }
  }.apply();
}
