package models;

import models.User;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.junit.Assert;
import org.junit.Test;

@SuppressWarnings("all")
public class UserTest {
  private final String userStr = "User [\n  _id = 0\n  _firstname = \"homer\"\n  _lastname = \"simpson\"\n  _email = \"homer@simpson.com\"\n  _password = \"secret\"\n  _activities = {}\n]";
  
  private final User homer = new Function0<User>() {
    public User apply() {
      User _user = new User(Long.valueOf(0l), "homer", "simpson", "homer@simpson.com", "secret");
      return _user;
    }
  }.apply();
  
  @Test
  public void testCreate() {
    String _firstname = this.homer.getFirstname();
    Assert.assertEquals("homer", _firstname);
    String _lastname = this.homer.getLastname();
    Assert.assertEquals("simpson", _lastname);
    String _email = this.homer.getEmail();
    Assert.assertEquals("homer@simpson.com", _email);
    String _password = this.homer.getPassword();
    Assert.assertEquals("secret", _password);
  }
  
  @Test
  public void testToString() {
    String _string = this.homer.toString();
    Assert.assertEquals(this.userStr, _string);
  }
}
